How to compile
npm start
> i already set up the package.json to compile it to js first and then run the js file