import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class GroupExpense {
    @PrimaryGeneratedColumn()
    id: number

    @Column()
    groupname: string;

    @Column()
    type: string;

    @Column()
    amount: number;

    @Column()
    createdBy: string;

    @Column()
    createdOn: Date;
}