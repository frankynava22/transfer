import express from 'express';
import { ApolloServer } from '@apollo/server';
import { ApolloServerPluginDrainHttpServer } from '@apollo/server/plugin/drainHttpServer';
import { expressMiddleware } from '@apollo/server/express4';
import { AppDataSource } from './data-source.js';
import "reflect-metadata";
import http from 'http';


//define our schema
//basically the structure of our data 
const typeDefs = `#graphql
    #queryable fields for our custom type User
    #ID is a unique indentier, ! makes it required
    type User{
        id: ID! 
        name: String
        username: String
        password: String
    }

    #Client accessible queries
    type Query{
        #return an array of books
        users: [User]
    }
`;

//we define resolvers to point to the data to display for the queries
//this is where the data goes in
const resolvers = {
    Query: {
        users: () => userData,
    },
};


//mock data
const userData = [
    { id: 1, name: "Franky", username: "fnava", password: "Password222" },
    { id: 2, name: "Tristan", username: "thern", password: "Simple200" }
]

//initialize datasource
async function main() {
    console.log(process.cwd());
    try {
        AppDataSource.initialize();

        //apollo server requires two parameters, typeDefs and resolvers
        //creates an express app and uses apollo server as middleware
        async function startApolloServer(typeDefs, resolvers) {
            const app = express();
            const httpServer = http.createServer(app);

            //requests are in the form of json
            app.use(express.json())

            //server constructor
            const server = new ApolloServer({
                typeDefs,
                resolvers,
                plugins: [ApolloServerPluginDrainHttpServer({ httpServer })],
            });

            await server.start();
            app.use('/graphql', expressMiddleware(server, { context: async () => ({}) }));

            await new Promise<void>(resolve => httpServer.listen({ port: 4000 }, resolve));
            console.log(`Server Running at http://localhost:4000/graphql`);

            startApolloServer(typeDefs, resolvers);
        }
    }
    catch (err) {
        console.log(`Error conneted to DB ${err}`);
    }

}

main()


